variable "aws_region" {}
variable "aws_profile" {}
variable "bucket_name" {}
variable "environment" {}
variable "admin_user_arns" { type = "list" }
variable "rw_user_arns" { type = "list" }
variable "ro_user_arns" { type = "list" }

provider "aws" {
  region = "${var.aws_region}"
  profile = "${var.aws_profile}"
}

resource "aws_s3_bucket" "evolvestatic" {
  bucket = "${var.bucket_name}-${var.environment}"
  acl = "public-read"

  website {
    index_document = "index.html"
    error_document = "error.html"
  }
  policy = <<POLICY
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ListBucket",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:ListBucket",
      "Resource": "arn:aws:s3:::${var.bucket_name}-${var.environment}"
    },
    {
      "Sid": "AllowPublicRead",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::${var.bucket_name}-${var.environment}/*"
    },
    {
      "Sid": "Admin",
      "Effect": "Allow",
      "Principal": {
				"AWS": [
					"${join("\",\"", var.admin_user_arns)}"
				]
			},
      "Action": "s3:*",
      "Resource": "arn:aws:s3:::${var.bucket_name}-${var.environment}/*"
    },
    {
      "Sid": "RW",
      "Effect": "Allow",
      "Principal": {
        "AWS": [
          "${join("\",\"", var.rw_user_arns)}"
        ]
      },
      "Action": [
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::${var.bucket_name}-${var.environment}/*"
    }
  ]
}
POLICY
}

/*,
{
  "Sid": "RO",
  "Effect": "Allow",
  "Principal": {
    "AWS": [
      "${join("\",\"", var.ro_user_arns)}"
    ]
  },
  "Action": [
    "s3:GetObject"
  ],
  "Resource": "arn:aws:s3:::${var.bucket_name}-${var.environment}/*"
}*/
