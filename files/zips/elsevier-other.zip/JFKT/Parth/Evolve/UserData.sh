#!/bin/bash
#The line above was the easiest way to establish a files that contained the funtion what were are doing
#If the templates weren't together I would have created this file in the same place all the others are
#but both the webapps and the utils use the same section for that so that would not work.
yum install -y pystache python-daemon python-requests
/opt/aws/bin/cfn-init -s prod-webapps-ev -r WebServiceAutoScaleLaunchConfiguration --region us-east-1 --access-key AKIAIRPS6PT4L54VVKRQ --secret-key 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 -c default,appserver -v
/tmp/create_part.sh
/bin/sleep 5s
mkfs.ext4 /dev/xvdm1 >/tmp/mkfs.out 2<&1
mount /dev/xvdm1 /mnt
ln -s /home /apphome
mkdir -p -m 755 /apphome/evolve/evl/StaticContent/variables
mkdir -p -m 755 /home/evolve/evl/StaticContent/uploaded/images
mkdir -p -m 755 /apphome/evolve/evl/.install/Jobs
mkdir -p -m 755 /media/nfs/ppmdata
mkdir -p -m 755 /media/nfs/marketing-images
mkdir -p -m 755 /media/nfs/institutionUpload
mkdir -p -m 755 /mnt/evolve-logs
mkdir -p -m 755 /media/nfs/ppmdata/logs
mkdir -p -m 755 /media/nfs/ppmdata/archivedata
ln -s /mnt/evolve-logs /apphome/evolve/logs
ln -s /media/nfs/ppmdata /apphome/evolve/evl/ppmdata
ln -s /apphome/evolve/evl/.install/Jobs /apphome/evolve/evl/Jobs
ln -s /media/nfs/institutionUpload /home/evolve/EvolveUtils
ln -s /media/nfs/marketing-images /home/evolve/evl/StaticContent/uploaded/images
tar --extract --ungzip --strip-component=1 --file=/tmp/jetty/WebServiceAutoscaleGroup/EvlStaticContent.tgz --directory=/apphome/evolve/evl/StaticContent
tar --extract --ungzip --strip-component=1 --file=/tmp/jetty/WebServiceAutoscaleGroup/EvlConfig.tgz --directory=/apphome/evolve/evl/StaticContent/variables
/var/els/run_puppet.sh
/opt/jetty/current/bin/jetty.sh stop
chown -hR evolve:evolve /apphome/evolve/evl/.install
chown -hR evolve:evolve /apphome/evolve
chown -hR evolve:evolve /apphome/evolve/evl/ppmdata/logs
chown -hR evolve:evolve /apphome/evolve/evl/StaticContent/variables
chown -hR evolve:evolve /apphome/evolve/evl/StaticContent
chown -hR evolve:evolve /media/
chmod -R 777 /media/nfs/
cp /tmp/jetty/WebServiceAutoscaleGroup/ae.war /opt/jetty/current/webapps/
cp /tmp/jetty/WebServiceAutoscaleGroup/admin.war /opt/jetty/current/webapps/
cp /tmp/jetty/WebServiceAutoscaleGroup/portal.war /opt/jetty/current/webapps/
chown jetty:evolve /opt/jetty/current/webapps/admin.war
chown jetty:evolve /opt/jetty/current/webapps/ae.war
chown jetty:evolve /opt/jetty/current/webapps/portal.war
/opt/jetty/current/bin/jetty.sh start &
chage -I -1 -m -1 -M -1 -E -1 -W -1 -d -1 ec2-user
chage -I -1 -m -1 -M -1 -E -1 -W -1 -d -1 observer
chage -I -1 -m -1 -M -1 -E -1 -W -1 -d -1 evolve
chage -I -1 -m -1 -M -1 -E -1 -W -1 -d -1 jetty
chage -I -1 -m -1 -M -1 -E -1 -W -1 -d -1 zabbix
chage -I -1 -m -1 -M -1 -E -1 -W -1 -d -1 feeds
