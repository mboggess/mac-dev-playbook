#!/usr/local/bin/bash
###############################################################################

function setup_vars {
###############################################################################
#
# Allocate an *vpc* address and allocation ID
#
#STAGE1="`ec2-allocate-address -d vpc`"
##STAGE1="ADDRESS 54.209.159.3 vpc eipalloc-fdbaab9f"
#STAGE1="ADDRESS 54.208.196.204 vpc eipalloc-fdbaab9f"
#STAGE1="ADDRESS 54.208.196.203 vpc eipalloc-fdbaab9f"

# Get the instance ID
EC2_INSTANCE_ID="`curl --connect-timeout 3 http://169.254.169.254/latest/meta-data/instance-id`"
#EC2_INSTANCE_ID="i-ss-doosh"
#EC2_INSTANCE_ID="i-bda7bbd9"
###############################################################################
}


function allocate_ip {
###############################################################################
#
#Split the values in to an array to be used later.

	read -a array0 <<< $STAGE1

# We don't need 0 as it's the word ADDRESS
# 1 should be the address
# 2 should be vpc designation
# 3 should be allocation ID

NEW_EIP="${array0[1]}"
EC2_DESIGNATION="{array0[2]}"
ALLOC_ID="${array0[3]}"

ASSIGN_CMD="ec2-associate-address -i ${EC2_INSTANCE_ID} -a ${ALLOC_ID}"

echo "\$NEW_EIP = ${NEW_EIP}"

echo "\${array0[O]} = ${array0[O]}";echo "\${array0[1]} = ${array0[1]}";echo "\${array0[2]} = ${array0[2]}";echo "\${array0[3]} = ${array0[3]}"

###############################################################################
}


function test_new_ip {
###############################################################################
#
#Gather the existing IPs and test them against the newly allocated IP
#If they match, well, die...

echo "Testing to see if the E-IP is already assigned."

TEST_NEW_IP="`ec2-describe-addresses --show-empty-fields ${NEW_EIP} | awk {'print $3'}`"

# This describes the IP ADDRESS that was allocated..  Awks out the third field.
# The reason is simple, if the 3rd field is not (null) then clearly the IP has
# Something assigned to it already. I know dumb and redundant but one never knows.
###############################################################################

    if [ "${TEST_NEW_IP}" != "(nil)" ]; then
	echo "The E-IP is already in place or exists! EXITING...."
	exit -99
    fi
}

###############################################################################

function assign_ip {
echo "$ASSIGN_CMD"
}

#set -i
setup_vars

	if [ "$?" -ne "0" ]; then
echo "Something failed in fucntion \"setup_vars\"!"
	exit 1;
	fi
# If the setup_vars function failed then exit.

allocate_ip

	if [ "$?" -ne "0" ]; then
echo "Something failed in fucntion \"allocate_ip\"!"
	exit 1;
	fi
# If the allocate_ip function failed then exit.

test_new_ip

	if [ "$?" -ne "0" ]; then
echo "Something failed in fucntion \"test_new_ip\"!"
	exit 1;
	fi
# If the test_new_ip function failed then exit.

assign_ip

	if [ "$?" -ne "0" ]; then
echo "Something failed in fucntion \"assign_ip\"!"
	exit 1;
	fi
# If the allocate_ip function failed then exit.
