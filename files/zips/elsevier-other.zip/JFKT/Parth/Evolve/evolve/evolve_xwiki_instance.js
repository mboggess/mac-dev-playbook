{
  "AWSTemplateFormatVersion": "2010-09-09",
  "Description": "Template to create a sandbox environment",
  "Parameters": {
    "DNSDomain": {
      "Type": "String",
      "Description": "The DNS domain to create records in. Must be the complete domain name, ending in .",
      "AllowedPattern": "[a-z0-9_\\-\\.]*\\.$",
      "ConstraintDescription": "most only contain lower case letters, numbers, hyphens, periods, and underscores. It must end with a period"
    },
    "KeyPair": {
      "Type": "String",
      "Description": "Keypair name to use on this system. The keypair must already exist in EC2.",
      "Default": ""
    },
    "runLevel": {
      "Type": "String",
      "Description": "Contents of /l-n/app/etc/runLevel."
    }
  },
  "Mappings": {
    "RegionMap": {
      "us-east-1": {
        "app": "ami-5aab7033",
        "type": "m1.large"
      }
    }
  },
  "Resources": {
    "EnvironmentConfigDomain": {
      "Type": "AWS::SDB::Domain"
    },
    "WebServiceUser": {
      "Type": "AWS::IAM::User",
      "Properties": {
        "Path": "/",
        "Groups": [
          "route53-register",
          "puppet_access"
        ],
        "Policies": [
          {
            "PolicyName": "ConfigSDBAccessPolicy",
            "PolicyDocument": {
              "Statement": [
                {
                  "Effect": "Allow",
                  "Action": [
                    "sdb:DomainMetadata",
                    "sdb:GetAttributes",
                    "sdb:Select"
                  ],
                  "Resource": [
                    {
                      "Fn::Join": [
                        ":",
                        [
                          "arn",
                          "aws",
                          "sdb",
                          {
                            "Ref": "AWS::Region"
                          },
                          "*",
                          {
                            "Fn::Join": [
                              "/",
                              [
                                "domain",
                                {
                                  "Ref": "EnvironmentConfigDomain"
                                }
                              ]
                            ]
                          }
                        ]
                      ]
                    }
                  ]
                }
              ]
            }
          }
        ]
      }
    },
    "WebServiceUserKey": {
      "Type": "AWS::IAM::AccessKey",
      "Properties": {
        "Serial": 1,
        "UserName": {
          "Ref": "WebServiceUser"
        }
      }
    },
    "WikiServiceAutoscaleGroup": {
      "Type": "AWS::AutoScaling::AutoScalingGroup",
      "Properties": {
        "AvailabilityZones": {
          "Fn::GetAZs": {
            "Ref": "AWS::Region"
          }
        },
        "Cooldown": "300",
        "DesiredCapacity": "1",
        "HealthCheckGracePeriod": "300",
        "HealthCheckType": "EC2",
        "LaunchConfigurationName": {
          "Ref": "WikiServiceAutoScaleLaunchConfiguration"
        },
        "MaxSize": "1",
        "MinSize": "1",
        "Tags": [
          {
            "Key": "Name",
            "Value": {
              "Fn::Join": [
                "-",
                [
                  "Wiki",
                  {
                    "Ref": "AWS::StackName"
                  }
                ]
              ]
            },
            "PropagateAtLaunch": "true"
          },
          {
            "Key": "ConfigDomain",
            "Value": {
              "Ref": "EnvironmentConfigDomain"
            },
            "PropagateAtLaunch": "true"
          }
        ]
      }
    },
    "WikiServiceAutoScaleLaunchConfiguration": {
      "Type": "AWS::AutoScaling::LaunchConfiguration",
      "Properties": {
        "ImageId": {
          "Fn::FindInMap": [
            "RegionMap",
            {
              "Ref": "AWS::Region"
            },
            "app"
          ]
        },
        "InstanceType": {
          "Fn::FindInMap": [
            "RegionMap",
            {
              "Ref": "AWS::Region"
            },
            "type"
          ]
        },
        "KeyName": {
          "Ref": "KeyPair"
        },
        "SecurityGroups": [
          {
            "Ref": "WikiServiceSG"
          }
        ],
        "UserData": {
          "Fn::Base64": {
            "Fn::Join": [
              "\n",
              [
                "#!/bin/bash",
                {
                  "Fn::Join": [
                    "=",
                    [
                      "ACCESS_KEY",
                      {
                        "Ref": "WebServiceUserKey"
                      }
                    ]
                  ]
                },
                {
                  "Fn::Join": [
                    "=",
                    [
                      "SECRET_KEY",
                      {
                        "Fn::GetAtt": [
                          "WebServiceUserKey",
                          "SecretAccessKey"
                        ]
                      }
                    ]
                  ]
                },
                "mkdir -p /var/els/tmp",
                "cat >/var/els/tmp/.s3cfg<<EOF",
                "[default]",
                "access_key = $ACCESS_KEY",
                "secret_key = $SECRET_KEY",
                "use_https = True",
                "EOF",
                "/usr/bin/s3cmd -c /var/els/tmp/.s3cfg sync s3://evolve.aws.puppet/dev/puppet /var/els/",
                "cat >/var/els/creds.properties<<EOF",
                "accessKey = $ACCESS_KEY",
                "secretKey = $SECRET_KEY",
                {
                  "Fn::Join": [
                    "",
                    [
                      "dns.domain = ",
                      {
                        "Ref": "DNSDomain"
                      }
                    ]
                  ]
                },
                {
                  "Fn::Join": [
                    "",
                    [
                      "envConfigDomain = ",
                      {
                        "Ref": "EnvironmentConfigDomain"
                      }
                    ]
                  ]
                },
                "EOF",
                "cat >/var/els/puppet/manifests/nodes.pp<<EOF",
                "node default {",
                "  class {'java' : version => '1.6.0_33-fcs'}",
                "  include jetty",
                "  include evolve",
                "  include emacs",
                "  include evolve::zabbix_register",
                "}",
                "EOF",
                "",
                "rm -rf /var/els/tmp",
                "/usr/bin/puppet apply /var/els/puppet/manifests/site.pp --modulepath /var/els/puppet/modules --debug",
                "",
                "mkdir -p /l-n/app/etc/",
                "cat > /l-n/app/etc/runLevel<<EOF",
                {
                  "Ref": "runLevel"
                },
                "EOF",
                "touch /etc/default/evolve",
                "cat > /etc/default/evolve<<EOF",
                {
                  "Ref": "runLevel"
                },
                "EOF",
                "touch /etc/default/jetty",
                "cat > /etc/default/jetty<<EOF",
                {
                  "Ref": "runLevel"
                },
                "EOF"
              ]
            ]
          }
        }
      }
    },
    "EnvironmentConfigDomain": {
      "Type": "AWS::SDB::Domain"
    },
    "WikiServiceSG": {
      "Type": "AWS::EC2::SecurityGroup",
      "Properties": {
        "GroupDescription": "Security Group to contain the possible utility server",
        "SecurityGroupIngress": [
          {
            "IpProtocol": "tcp",
            "CidrIp": "198.185.18.72/32",
            "FromPort": "22",
            "ToPort": "22"
          },
          {
            "IpProtocol": "tcp",
            "SourceSecurityGroupId": "sg-7c37bf14",
            "SourceSecurityGroupOwnerId": "288860632658",
            "FromPort": "10050",
            "ToPort": "10052"
          },
          {
            "IpProtocol": "tcp",
            "CidrIp": "0.0.0.0/0",
            "FromPort": "80",
            "ToPort": "80"
          }
        ]
      }
    }
  },
  "Outputs": {
    "ConfigXML": {
      "Value": {
        "Fn::Join": [
          "\n",
          [
            "<Domain>",
            "  <Item id=\"configuration\">",
            "  </Item>",
            "</Domain>"
          ]
        ]
      }
    }
  }
}
