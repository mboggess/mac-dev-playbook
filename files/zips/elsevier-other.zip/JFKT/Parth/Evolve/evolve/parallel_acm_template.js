{
    "AWSTemplateFormatVersion":"2010-09-09",
    "Description":"Template to create a ACM environment",
    "Parameters":{
        "DNSDomain":{
            "Type":"String",
            "Description":"The DNS domain to create records in. Must be the complete domain name, ending in .",
            "AllowedPattern":"[a-z0-9_\\-\\.]*\\.$",
            "ConstraintDescription":"most only contain lower case letters, numbers, hyphens, periods, and underscores. It must end with a period"
        },
        "KeyPair":{
            "Type":"String",
            "Description":"Keypair name to use on this system. The keypair must already exist in EC2.",
            "Default":""
        },
        "Environment":{
            "Type":"String",
            "Description":"Environemnt: dev, cert, prod"
        },
        "PuppetVersion": {
            "Type": "String",
            "Description": "Version of the puppet modules. Must include leading 0s.",
            "AllowedPattern": "^[0-9][0-9][0-9][0-9][0-9]$"
        }
    },
    "Mappings":{
        "RegionMap":{
            "us-east-1":{
                "app":"ami-5aab7033",
                "type":"m1.small"
            }
        },
        
        "DNSMap":{
            "dev":{
                "acm": "acm-dev-new.ehsevolve.com"
            },
            "cert":{
                "acm": "acm-cert-new.ehsevolve.com"
            },
            "prod":{
                "acm": "acm-new.ehsevolve.com"
            }
        }
    },
    
    "Resources":{
        "ACMServiceSG":{
            "Type":"AWS::EC2::SecurityGroup",
            "Properties":{
                "GroupDescription":"Security Group to contain the InfoButton Manager server",
                "SecurityGroupIngress":[
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"22",
                        "ToPort":"22"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"80",
                        "ToPort":"80"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"443",
                        "ToPort":"443"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"9090",
                        "ToPort":"9090"
                    },
                    {
                        "IpProtocol":"tcp",
                        "SourceSecurityGroupId": "sg-7c37bf14",
                        "SourceSecurityGroupOwnerId": "288860632658",
                        "FromPort":"10050",
                        "ToPort":"10052"
                    }
                ]
            }
        },
        "InternalIngress":{
            "Type":"AWS::EC2::SecurityGroupIngress",
            "Properties":{
                "GroupName":{
                    "Ref":"ACMServiceSG"
                },
                "IpProtocol":"tcp",
                "FromPort":"0",
                "ToPort":"65535",
                "SourceSecurityGroupName":{
                    "Ref":"ACMServiceSG"
                }
            }
        },
        "ACMServiceELBIngress":{
            "Type":"AWS::EC2::SecurityGroupIngress",
            "Properties":{
                "GroupName":{
                    "Ref":"ACMServiceSG"
                },
                "IpProtocol":"tcp",
                "FromPort":"9090",
                "ToPort":"9090",
                "SourceSecurityGroupOwnerId":{
                    "Fn::GetAtt":[
                        "ACMServiceELB",
                        "SourceSecurityGroup.OwnerAlias"
                    ]
                },
                "SourceSecurityGroupName":{
                    "Fn::GetAtt":[
                        "ACMServiceELB",
                        "SourceSecurityGroup.GroupName"
                    ]
                }
            }
        },
        "ACMServiceELB":{
            "Type":"AWS::ElasticLoadBalancing::LoadBalancer",
            "Properties":{
                "AvailabilityZones":{
                    "Fn::GetAZs":{
                        "Ref":"AWS::Region"
                    }
                },
                "HealthCheck":{
                    "HealthyThreshold":"3",
                    "Interval":"5",
                    "Target":"HTTP:9090/MANIFEST.MF",
                    "Timeout":"3",
                    "UnhealthyThreshold":"2"
                },
                "Listeners":[
                    {
                        "Protocol":"HTTP",
                        "LoadBalancerPort":"80",
                        "InstancePort":"9090"
                    }
                ]
            }
        },
        "ACMServiceELBDNS":{
            "Type":"AWS::Route53::RecordSetGroup",
            "Properties":{
                "HostedZoneName":{
                    "Ref":"DNSDomain"
                },
                "Comment":{
                    "Fn::Join":[
                        "",
                        [
                            "Alias record for ACM Stack ",
                            {
                                "Ref":"DNSDomain"
                            },
                            "."
                        ]
                    ]
                },
                "RecordSets":[
                    {
                        "Name" : { "Fn::Join" : [".", [
                                { "Ref" : "AWS::StackName" },
                                { "Ref" : "DNSDomain" }
                            ] ]
                        },
                        "Type" : "A",
                        "AliasTarget" : {
                            "HostedZoneId" : { "Fn::GetAtt" : [ "ACMServiceELB", "CanonicalHostedZoneNameID" ] },
                            "DNSName" : { "Fn::GetAtt" : [ "ACMServiceELB", "CanonicalHostedZoneName" ] }
                        }
                    },
                    {
                        "Name" : {"Fn::FindInMap": ["DNSMap", {"Ref":"Environment"}, "acm"]},
                        "Type" : "A",
                        "AliasTarget" : {
                            "HostedZoneId" : { "Fn::GetAtt" : [ "ACMServiceELB", "CanonicalHostedZoneNameID" ] },
                            "DNSName" : { "Fn::GetAtt" : [ "ACMServiceELB", "CanonicalHostedZoneName" ] }
                        }
                    }
                ]
            }
        },
        "ACMServiceAutoscaleGroup":{
            "Type":"AWS::AutoScaling::AutoScalingGroup",
            "Properties":{
                "AvailabilityZones":{
                    "Fn::GetAZs":{
                        "Ref":"AWS::Region"
                    }
                },
                "Cooldown":"300",
                "DesiredCapacity":"1",
                "HealthCheckGracePeriod":"300",
                "HealthCheckType":"EC2",
                "LaunchConfigurationName":{
                    "Ref":"ACMServiceAutoScaleLaunchConfiguration"
                },
                "LoadBalancerNames":[
                    {
                        "Ref":"ACMServiceELB"
                    }
                ],
                "MaxSize":"1",
                "MinSize":"1",
                "Tags":[
                    {
                        "Key":"Name",
                        "Value":{
                            "Fn::Join":[
                                "-",
                                [
                                    "evolve",
                                    {
                                        "Ref":"AWS::StackName"
                                    }
                                ]
                            ]
                        },
                        "PropagateAtLaunch":"true"
                    },
                    {
                        "Key":"ConfigDomain",
                        "Value":{
                            "Ref":"EnvironmentConfigDomain"
                        },
                        "PropagateAtLaunch":"true"
                    }
                ]
            }
        },
        "ACMServiceAutoScaleLaunchConfiguration":{
            "Type":"AWS::AutoScaling::LaunchConfiguration",
            "Metadata": {
                "AWS::CloudFormation::Authentication" : {
                    "BucketAccess" : {
                        "type" : "S3",
                        "accessKeyId" : { "Ref" : "ACMServiceUserKey" },
                        "secretKey" : { "Fn::GetAtt" : [ "ACMServiceUserKey", "SecretAccessKey" ] },
                        "buckets" : [ "evolve.aws.puppet" ]
                    }
                },
                "AWS::CloudFormation::Init" : {
                    "configSets": {
                        "default":   [ "security", "configfiles", "installs" ],
                        "acm": [ "acm-config" ]
                    },

                    "security" : {
                        "commands" : {
                            "05-yum-update-security" : {
                                "command" : "yum update -y --security --exclude kernel*"
                            }
                        }
                    },

                    "configfiles": {
                        "files": {
                            "/etc/configure.creds" : {
                                "mode" : "000400",
                                "owner" : "root",
                                "group" : "wheel",
                                "content" : { "Fn::Join" : [ "", [
                                    "AWSAccessKeyId=",
                                    { "Ref" : "ACMServiceUserKey" },
                                    "\n",
                                    "AWSSecretKey=",
                                    { "Fn::GetAtt" : [ "ACMServiceUserKey", "SecretAccessKey" ] },
                                    "\n",
                                    "MetadataObject=WebServiceAutoScaleLaunchConfiguration",
                                    "\n"
                                ]]}
                            },
                            "/l-n/app/etc/runLevel": {
                                "mode": "000644",
                                "owner": "root",
                                "group": "root",
                                "content": { "Ref": "Environment" }
                            },
                            "/etc/default/evolve": {
                                "mode": "000644",
                                "owner": "root",
                                "group": "root",
                                "content": { "Ref": "Environment" }
                            },
                            "/etc/default/jetty": {
                                "mode": "000644",
                                "owner": "root",
                                "group": "root",
                                "content": { "Ref": "Environment" }
                            }
                        },

                        "commands": {
                            "enableepel" : {
                                "command" : "sed -i '0,/enabled=0/s/enabled=0/enabled=1/' /etc/yum.repos.d/epel.repo",
                                "test" : "! grep -q 'enabled=1' /etc/yum.repos.d/epel.repo" 
                            },
                            "importepelkey" : {
                                "command" : "KEY=$(grep 'gpgkey' /etc/yum.repos.d/epel.repo | head -1 | cut -f 2 -d '=') && rpm --import $KEY"
                            }
                        }
                    },

                    "installs": {
                        "packages": {
                            "yum": {
                                "puppet":   []
                            }
                        },
                        
                        "sources": {
                            "/var/els" : { "Fn::Join": ["", ["https://s3.amazonaws.com/evolve.aws.puppet/dev/tars/puppet-", { "Ref" : "PuppetVersion" }, ".tar.gz" ] ] }
                        }
                    },

                    "acm-config": {
                        "files": {
                            "/var/els/puppet/manifests/nodes.pp": {
                                "mode": "000644",
                                "owner": "root",
                                "group": "root",
                                "content": {"Fn::Join": ["\n", [
                                    "node default {",
                                    "  class {'java' : package => 'jdk', version => '1.6.0_45-fcs'}",
                                    "  include evolve::acm_user",
                                    "  include evolve::acm_root_content",
                                    "  include evolve::acm_zabbix_register",
                                    "  include evolve::acm_appdir",
                                    "  include evolve::acm_logdir",
                                    "  include evolve::acm_scripts",
                                    "  include timezone::utc",
                                    "  include deploy",
                                        "}"
                                ] ] }
                            }
                        }
                    }   
                }
            },
            "Properties":{
                "ImageId":{
                    "Fn::FindInMap":[
                        "RegionMap",
                        {
                            "Ref":"AWS::Region"
                        },
                        "app"
                    ]
                },
                "InstanceType":{
                    "Fn::FindInMap":[
                        "RegionMap",
                        {
                            "Ref":"AWS::Region"
                        },
                        "type"
                    ]
                },
                "KeyName":{
                    "Ref":"KeyPair"
                },
                "SecurityGroups":[
                    {
                        "Ref":"ACMServiceSG"
                    }
                ],
                "UserData":{
                    "Fn::Base64":{
                        "Fn::Join":[
                            "\n",
                            [
                                "#!/bin/bash",
                                "# Install cfn-bootstrap tools and dependancies",
                                "yum install -y pystache python-daemon python-requests",
                                "rpm -ihv 'http://com.ptgels.yum.s3.amazonaws.com/prod/RPMS/6/x86_64/a/aws-cfn-bootstrap-1.3-b123.noarch.rpm?Signature=DeQCtrVFJ7S8UyfCOI89gsbrcRE%3D&Expires=1687794783&AWSAccessKeyId=AKIAIORP42DF6SY7FVRA&x-amz-meta-s3cmd-attrs=uid%3A48/gname%3Aapache/uname%3Aapache/gid%3A48/mode%3A33188/mtime%3A1379338448/atime%3A1379361086/ctime%3A1379361085'",
                                { "Fn::Join" : [ " ", [
                                  "/opt/aws/bin/cfn-init",
                                  "-s",
                                  { "Ref" : "AWS::StackName" },
                                  "-r",
                                  "ACMServiceAutoScaleLaunchConfiguration",
                                  "--region",
                                  { "Ref" : "AWS::Region" },
                                  "--access-key",
                                  { "Ref" : "ACMServiceUserKey" },
                                  "--secret-key",
                                  { "Fn::GetAtt" : [ "ACMServiceUserKey", "SecretAccessKey" ] },
                                  "-c",
                                  "default,acm",
                                  "-v"
                                ]]},
                                "",
                                "/usr/bin/puppet apply /var/els/puppet/manifests/site.pp --modulepath /var/els/puppet/modules --debug",
                                "",
                                "cat >/etc/default/acm<<EOF",
                                {
                                    "Fn::Join":[
                                        "",
                                        [
                                            "run_level=",
                                            {
                                                "Ref":"Environment"
                                            }
                                        ]
                                    ]
                                },
                                "#RINGO_OPTIONS=\"-J-agentpath:/opt/ssr/dynatrace/current/agent/lib64/libdtagent.so=name=ACM_EC2EAST_CERT_$(hostname),server=dtcollector-prodpurepath02.gh214.com\"",
                                "#RINGO_OPTIONS=\"-J-agentpath:/opt/ssr/dynatrace/current/agent/lib64/libdtagent.so=name=ACM_EC2EAST_PROD_$(hostname),server=dtcollector-prodpurepath02.gh214.com\"",
                                "EOF"
                            ]
                        ]
                    }
                }
            }
        },
        "ACMUser":{
            "Type":"AWS::DynamoDB::Table",
            "Properties":{
                "KeySchema":{
                    "HashKeyElement":{
                        "AttributeName":"ApplicationId",
                        "AttributeType":"S"
                    },
                    "RangeKeyElement":{
                        "AttributeName":"UserId",
                        "AttributeType":"S"
                    }
                },
                "ProvisionedThroughput":{
                    "ReadCapacityUnits":10,
                    "WriteCapacityUnits":10
                }
            }
        },
        "Node":{
            "Type":"AWS::DynamoDB::Table",
            "Properties":{
                "KeySchema":{
                    "HashKeyElement":{
                        "AttributeName":"NodeId",
                        "AttributeType":"S"
                    }
                },
                "ProvisionedThroughput":{
                    "ReadCapacityUnits":10,
                    "WriteCapacityUnits":10
                }
            }
        },
        "ACMServiceUserKey":{
            "Type":"AWS::IAM::AccessKey",
            "Properties":{
                "Serial":1,
                "UserName":{
                    "Ref":"ACMServiceUser"
                }
            }
        },
        "EnvironmentConfigDomain":{
            "Type":"AWS::SDB::Domain"
        },
        "ACMServiceUser":{
            "Type":"AWS::IAM::User",
            "Properties":{
                "Path":"/",
                "Groups":[
                    "route53-register",
                    "puppet_access"
                ],
                "Policies":[
                    {
                        "PolicyName":"ConfigSDBAccessPolicy",
                        "PolicyDocument":{
                            "Statement":[
                                {
                                    "Effect":"Allow",
                                    "Action":[
                                        "sdb:DomainMetadata",
                                        "sdb:GetAttributes",
                                        "sdb:Select"
                                    ],
                                    "Resource":[
                                        {
                                            "Fn::Join":[
                                                ":",
                                                [
                                                    "arn",
                                                    "aws",
                                                    "sdb",
                                                    {
                                                        "Ref":"AWS::Region"
                                                    },
                                                    "*",
                                                    {
                                                        "Fn::Join":[
                                                            "/",
                                                            [
                                                                "domain",
                                                                {
                                                                    "Ref":"EnvironmentConfigDomain"
                                                                }
                                                            ]
                                                        ]
                                                    }
                                                ]
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                ]
            }
        }
    },
    "Outputs":{
        "ConfigXML":{
            "Value":{
                "Fn::Join":[
                    "\n",
                    [
                        "<Domain>",
                        "  <Item id=\"configuration\">",
                        "  </Item>",
                        "</Domain>"
                    ]
                ]
            }
        }
    }
}
