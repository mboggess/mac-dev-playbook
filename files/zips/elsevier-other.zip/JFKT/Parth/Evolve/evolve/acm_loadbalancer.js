{
    "AWSTemplateFormatVersion":"2010-09-09",
    "Description":"Template to create ACM apache Load balancers",
    "Parameters":{
        "DNSDomain":{
            "Type":"String",
            "Description":"The DNS domain to create records in. Must be the complete domain name, ending in .",
            "AllowedPattern":"[a-z0-9_\\-\\.]*\\.$",
            "ConstraintDescription":"most only contain lower case letters, numbers, hyphens, periods, and underscores. It must end with a period"
        },
        "KeyPair":{
            "Type":"String",
            "Description":"Keypair name to use on this system. The keypair must already exist in EC2.",
            "Default":""
        },
        "runLevel":{
            "Type":"String",
            "Description":"Contents of /l-n/app/etc/runLevel."
        }
    },
    "Mappings":{
        "RegionMap":{
            "us-east-1":{
                "app":"ami-5aab7033",
                "type":"m1.small"
            }
        }
    },
    "Resources":{
        "ACMLBServiceSG":{
            "Type":"AWS::EC2::SecurityGroup",
            "Properties":{
                "GroupDescription":"Security Group to contain the SSO ProxyLB Hosts",
                "SecurityGroupIngress":[
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"22",
                        "ToPort":"22"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"0.0.0.0/0",
                        "FromPort":"80",
                        "ToPort":"80"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"0.0.0.0/0",
                        "FromPort":"443",
                        "ToPort":"443"
                    },
                    {
                        "IpProtocol":"tcp",
                        "SourceSecurityGroupId": "sg-7c37bf14",
                        "SourceSecurityGroupOwnerId": "288860632658",
                        "FromPort":"10050",
                        "ToPort":"10052"
                    }
                ]
            }
        },
        "ACMLBServiceAutoscaleGroup":{
            "Type":"AWS::AutoScaling::AutoScalingGroup",
            "Properties":{
                "AvailabilityZones":{
                    "Fn::GetAZs":{
                        "Ref":"AWS::Region"
                    }
                },
                "Cooldown":"300",
                "DesiredCapacity":"2",
                "HealthCheckGracePeriod":"300",
                "HealthCheckType":"EC2",
                "LaunchConfigurationName":{
                    "Ref":"ACMLBServiceAutoScaleLaunchConfiguration"
                },
                "MaxSize":"2",
                "MinSize":"2",
                "Tags":[
                    {
                        "Key":"Name",
                        "Value":{
                            "Fn::Join":[
                                "-",
                                [
                                    "acmlbservice",
                                    {
                                        "Ref":"AWS::StackName"
                                    }
                                ]
                            ]
                        },
                        "PropagateAtLaunch":"true"
                    },
                    {
                        "Key":"ConfigDomain",
                        "Value":{
                            "Ref":"EnvironmentConfigDomain"
                        },
                        "PropagateAtLaunch":"true"
                    }
                ]
            }
        },
        "ACMLBServiceAutoScaleLaunchConfiguration":{
            "Type":"AWS::AutoScaling::LaunchConfiguration",
            "Properties":{
                "ImageId":{
                    "Fn::FindInMap":[
                        "RegionMap",
                        {
                            "Ref":"AWS::Region"
                        },
                        "app"
                    ]
                },
                "InstanceType":{
                    "Fn::FindInMap":[
                        "RegionMap",
                        {
                            "Ref":"AWS::Region"
                        },
                        "type"
                    ]
                },
                "KeyName":{
                    "Ref":"KeyPair"
                },
                "SecurityGroups":[
                    {
                        "Ref":"ACMLBServiceSG"
                    }
                ],
                "UserData":{
                    "Fn::Base64":{
                        "Fn::Join":[
                            "\n",
                            [
                                "#!/bin/bash",
                                {
                                    "Fn::Join":[
                                        "=",
                                        [
                                            "ACCESS_KEY",
                                            {
                                                "Ref":"ACMLBServiceUserKey"
                                            }
                                        ]
                                    ]
                                },
                                {
                                    "Fn::Join":[
                                        "=",
                                        [
                                            "SECRET_KEY",
                                            {
                                                "Fn::GetAtt":[
                                                    "ACMLBServiceUserKey",
                                                    "SecretAccessKey"
                                                ]
                                            }
                                        ]
                                    ]
                                },
                                "mkdir -p /var/els/tmp",
                                "cat >/var/els/tmp/.s3cfg<<EOF",
                                "[default]",
                                "access_key = $ACCESS_KEY",
                                "secret_key = $SECRET_KEY",
                                "use_https = True",
                                "EOF",
                                "/usr/bin/s3cmd -c /var/els/tmp/.s3cfg sync s3://evolve.aws.puppet/dev/puppet /var/els/",
                                "cat >/var/els/creds.properties<<EOF",
                                "accessKey = $ACCESS_KEY",
                                "secretKey = $SECRET_KEY",
                                {
                                    "Fn::Join":[
                                        "",
                                        [
                                            "dns.domain = ",
                                            {
                                                "Ref":"DNSDomain"
                                            }
                                        ]
                                    ]
                                },
                                {
                                    "Fn::Join":[
                                        "",
                                        [
                                            "envConfigDomain = ",
                                            {
                                                "Ref":"EnvironmentConfigDomain"
                                            }
                                        ]
                                    ]
                                },
                                "EOF",
                                "cat >/var/els/puppet/manifests/nodes.pp<<EOF",
                                "node default {",
                                "  include emacs",
                                "  include evolve::apache_certs",
                                "  include evolve::acm_loadbalancer",
                                "  include evolve::loadbalancer_logging",
                                "  include evolve::acm_zabbix_register",
                                "  include evolve::acm_root_content", 
                                "  include evolve::observer_user",
                                "  include timezone::utc",
                                "}",
                                "EOF",
                                "",
                                "rm -rf /var/els/tmp",
                                "/usr/bin/puppet apply /var/els/puppet/manifests/site.pp --modulepath /var/els/puppet/modules --debug",
                                "",
                                "EOF"
                            ]
                        ]
                    }
                }
            }
        },
        "ACMLBServiceUser":{
            "Type":"AWS::IAM::User",
            "Properties":{
                "Path":"/",
                "Groups":[
                    "route53-register",
                    "puppet_access"
                ],
                "Policies":[
                    {
                        "PolicyName":"ConfigSDBAccessPolicy",
                        "PolicyDocument":{
                            "Statement":[
                                {
                                    "Effect":"Allow",
                                    "Action":[
                                        "sdb:DomainMetadata",
                                        "sdb:GetAttributes",
                                        "sdb:Select"
                                    ],
                                    "Resource":[
                                        {
                                            "Fn::Join":[
                                                ":",
                                                [
                                                    "arn",
                                                    "aws",
                                                    "sdb",
                                                    {
                                                        "Ref":"AWS::Region"
                                                    },
                                                    "*",
                                                    {
                                                        "Fn::Join":[
                                                            "/",
                                                            [
                                                                "domain",
                                                                {
                                                                    "Ref":"EnvironmentConfigDomain"
                                                                }
                                                            ]
                                                        ]
                                                    }
                                                ]
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                ]
            }
        },
        "ACMLBServiceUserKey":{
            "Type":"AWS::IAM::AccessKey",
            "Properties":{
                "Serial":1,
                "UserName":{
                    "Ref":"ACMLBServiceUser"
                }
            }
        },
        "EnvironmentConfigDomain":{
            "Type":"AWS::SDB::Domain"
        }
    },
    "Outputs":{
        "ConfigXML":{
            "Value":{
                "Fn::Join":[
                    "\n",
                    [
                        "<Domain>",
                        "  <Item id=\"configuration\">",
                        "  </Item>",
                        "</Domain>"
                    ]
                ]
            }
        }
    }
}
