{
    "AWSTemplateFormatVersion":"2010-09-09",
    "Description":"Template to create Evolve Jetty services boxes.",
    "Parameters":{
        "DNSDomain":{
            "Type":"String",
            "Description":"The DNS domain to create records in. Must be the complete domain name, ending in .",
            "AllowedPattern":"[a-z0-9_\\-\\.]*\\.$",
            "ConstraintDescription":"most only contain lower case letters, numbers, hyphens, periods, and underscores. It must end with a period"
        },
        "KeyPair":{
            "Type":"String",
            "Description":"Keypair name to use on this system. The keypair must already exist in EC2."
        },
        "Environment":{
            "Type":"String",
            "Description":"Environemnt: dev, cert, prod"
        },
        "PuppetVersion": {
            "Type": "String",
            "Description": "Version of the puppet modules. Must include leading 0s.",
            "AllowedPattern": "^[0-9][0-9][0-9][0-9][0-9]$"
        }
    },
    "Mappings":{
        "RegionMap":{
            "us-east-1":{
                "app":"ami-5aab7033",
                "type":"m1.large"
            }
        },
        "DNSMap":{
            "development":{
                "solr": "solr-mstr-dev.ehsevolve.com",
                "utils": "utils-dev.ehsevolve.com",
                "portal": "portal-services-dev.ehsevolve.com",
                "admin": "admin-services-dev.ehsevolve.com"
                
            },
            "certification":{
                "solr": "solr-mstr-cert.ehsevolve.com",
                "utils": "utils-cert.ehsevolve.com",
                "portal": "portal-services-cert.ehsevolve.com",
                "admin": "admin-services-cert.ehsevolve.com"
            },
            "production":{
                "solr": "solr-mstr.ehsevolve.com",
                "utils": "utils.ehsevolve.com",
                "portal": "portal-services.ehsevolve.com",
                "admin": "admin-services.ehsevolve.com"
            }
        }
        
    },
    "Resources":{
        "WebServiceSG":{
            "Type":"AWS::EC2::SecurityGroup",
            "Properties":{
                "GroupDescription":"Security Group to contain the Web Server Hosts",
                "SecurityGroupIngress":[
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"22",
                        "ToPort":"22"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"8080",
                        "ToPort":"8080"
                    },
                    {
                      "IpProtocol" : "tcp",
                      "CidrIp" : "75.13.130.62/32",
                      "FromPort" : "22",
                      "ToPort" : "22"
                    },
                    {
                      "IpProtocol" : "tcp",
                      "CidrIp" : "75.13.130.62/32",
                      "FromPort" : "8080",
                      "ToPort" : "8080"
                    },
                    {
                        "IpProtocol":"tcp",
                        "SourceSecurityGroupId": "sg-7c37bf14",
                        "SourceSecurityGroupOwnerId": "288860632658",
                        "FromPort":"10050",
                        "ToPort":"10052"
                    }
                ]
            }
        },
        "WebServiceELBIngress8080": {
			"Type" : "AWS::EC2::SecurityGroupIngress",
			"Properties" : {
			    "GroupName": {"Ref": "WebServiceSG"},
				"IpProtocol" : "tcp",
				"FromPort" : "8080",
				"ToPort" : "8080",
				"SourceSecurityGroupOwnerId" : {"Fn::GetAtt": ["WebServiceELB", "SourceSecurityGroup.OwnerAlias"]},
				"SourceSecurityGroupName": { "Fn::GetAtt": ["WebServiceELB", "SourceSecurityGroup.GroupName"]}
			}
		},  		
        "WebServiceDNS" : {
    		"Type" : "AWS::Route53::RecordSetGroup",
    		"Properties" : {
    			"HostedZoneName" : { "Ref" : "DNSDomain" },
    			"Comment" : { "Fn::Join" : ["", [
    			            "Alias record for Elastic Loadbalancer ",
    			            { "Ref" : "DNSDomain" },
    			            "."
    			        ]
    			    ]
    			},
    			"RecordSets" : [
    			    {
    			    	"Name" : {"Fn::FindInMap": ["DNSMap", {"Ref":"Environment"}, "admin"]},
	    				"Type" : "A",
	    				"AliasTarget" : {
	    					"HostedZoneId" : { "Fn::GetAtt" : [ "WebServiceELB", "CanonicalHostedZoneNameID" ] },
	    					"DNSName" : { "Fn::GetAtt" : [ "WebServiceELB", "CanonicalHostedZoneName" ] }
	    				}
    			    },
    			    {
    			    	"Name" : {"Fn::FindInMap": ["DNSMap", {"Ref":"Environment"}, "portal"]},
	    				"Type" : "A",
	    				"AliasTarget" : {
	    					"HostedZoneId" : { "Fn::GetAtt" : [ "WebServiceELB", "CanonicalHostedZoneNameID" ] },
	    					"DNSName" : { "Fn::GetAtt" : [ "WebServiceELB", "CanonicalHostedZoneName" ] }
	    				}
    			    }
    			]	
    		}
    	},
        
        "WebServiceELB" : {
    		"Type" : "AWS::ElasticLoadBalancing::LoadBalancer",
    		"Properties" : {
				"AvailabilityZones" : { "Fn::GetAZs" : { "Ref" : "AWS::Region" } },
    			"HealthCheck" : {
    				"HealthyThreshold" : "3",
    				"Interval" : "5",
    				"Target" : "HTTP:8080/solr/select?q=%28%28author%3A%28*jarvis*%29^35%20OR%20name%3A%28*jarvis*%29^30%20OR%20productTypeName%3A%28*jarvis*%29^27%20OR%20resourceId%3A%28*jarvis*%29^5%20OR%20isbn10%3A%28*jarvis*%29^10%20%29%20AND%20%28coreProductFlag%3A*Y*^50%20%20OR%20coreProductFlag%3A*N*^2%29%20%29AND%20role%3Afaculty%20AND%20faculty-publish-flag%3AY%20AND%20faculty-search-flag%3AY&rows=25&start=0&facet=true&wt=json&facet.field=productType&facet.field=availableFormat&facet.zeros=false&sort=score%20desc%2CcontactOriginRelevancy%20desc%2Crelevancy%20desc%2Cedition%20desc&fl=*%2Cscore&fq=",
    				"Timeout" : "3",
    				"UnhealthyThreshold" : "2"
    			},
    			"Listeners" : [
    				{
    					"Protocol" : "HTTP",
    					"LoadBalancerPort" : "80",
    					"InstancePort" : "8080"
    				},
    				{
    					"Protocol": "HTTPS",
    					"LoadBalancerPort": "443",
    					"InstancePort": "8080",
         				"SSLCertificateId" : "arn:aws:iam::735504175433:server-certificate/Users/whitea002/tmp/evolve/STAR_EHSEVOLVE_COM"
    				}
    			]
    		}
    	},
        "WebServiceAutoscaleGroup":{
            "Type":"AWS::AutoScaling::AutoScalingGroup",
            "Properties":{
                "AvailabilityZones":{
                    "Fn::GetAZs":{
                        "Ref":"AWS::Region"
                    }
                },
                "Cooldown":"300",
                "DesiredCapacity":"2",
                "HealthCheckGracePeriod":"300",
                "HealthCheckType":"EC2",
                "LaunchConfigurationName":{
                    "Ref":"WebServiceAutoScaleLaunchConfiguration"
                },
                "MaxSize":"4",
                "MinSize":"2",
                "LoadBalancerNames": [{ "Ref": "WebServiceELB"}],
                "Tags":[
                    { "Key":"Name",
                        "Value":{ "Fn::Join":[ "-", [ "appservice", { "Ref":"AWS::StackName"} ]]},
                        "PropagateAtLaunch":"true"
                    },
                    { "Key":"ConfigDomain",
                        "Value": { "Ref":"EnvironmentConfigDomain" },
                        "PropagateAtLaunch":"true"
                    }
                ]
            }
        },
        "WebServiceAutoScaleLaunchConfiguration":{
            "Type":"AWS::AutoScaling::LaunchConfiguration",
            "Metadata": {
                "AWS::CloudFormation::Authentication" : {
			 	    "BucketAccess" : {
			 	        "type" : "S3",
			 	        "accessKeyId" : { "Ref" : "WebServiceUserKey" },
			 	        "secretKey" : { "Fn::GetAtt" : [ "WebServiceUserKey", "SecretAccessKey" ] },
			 	        "buckets" : [ "evolve.aws.puppet" ]
			 	    }
		 		},
                "AWS::CloudFormation::Init" : {
			   		"configSets": {
			   		    "default":   [ "security", "configfiles", "installs" ],
                        "appserver": [ "appserver-config" ],
                        "utils":     [ "utils-config" ]
			  		},

                    "security" : {
                        "commands" : {
                            "05-yum-update-security" : {
			  		            "command" : "yum update -y --security --exclude kernel*"
			  		        }
                        }
                    },

                    "configfiles": {
                        "files": {
                            "/etc/configure.creds" : {
								"mode" : "000400",
								"owner" : "root",
								"group" : "wheel",
								"content" : { "Fn::Join" : [ "", [
									"AWSAccessKeyId=",
									{ "Ref" : "WebServiceUserKey" },
									"\n",
									"AWSSecretKey=",
									{ "Fn::GetAtt" : [ "WebServiceUserKey", "SecretAccessKey" ] },
									"\n",
									"MetadataObject=WebServiceAutoScaleLaunchConfiguration",
									"\n"
								]]}
                            },
                            "/l-n/app/etc/runLevel": {
                                "mode": "000644",
                                "owner": "root",
                                "group": "root",
                                "content": { "Ref": "Environment" }
                            },
                            "/etc/default/evolve": {
                                "mode": "000644",
                                "owner": "root",
                                "group": "root",
                                "content": { "Ref": "Environment" }
                            },
                            "/etc/default/jetty": {
                                "mode": "000644",
                                "owner": "root",
                                "group": "root",
                                "content": { "Ref": "Environment" }
                            }
						},

                        "commands": {
						    "enableepel" : {
						        "command" : "sed -i '0,/enabled=0/s/enabled=0/enabled=1/' /etc/yum.repos.d/epel.repo",
						        "test" : "! grep -q 'enabled=1' /etc/yum.repos.d/epel.repo" 
						    },
						    "importepelkey" : {
						        "command" : "KEY=$(grep 'gpgkey' /etc/yum.repos.d/epel.repo | head -1 | cut -f 2 -d '=') && rpm --import $KEY"
						    }
						}
                    },

                    "installs": {
                        "packages": {
                            "yum": {
                                "puppet":   []
                            }
                        },
                        
                        "sources": {
                            "/var/els" : { "Fn::Join": ["", ["https://s3.amazonaws.com/evolve.aws.puppet/dev/tars/puppet-", { "Ref" : "PuppetVersion" }, ".tar.gz" ] ] }
                        }
                    },

                    "appserver-config": {
                        "files": {
                            "/var/els/puppet/manifests/nodes.pp": {
                                "mode": "000644",
                                "owner": "root",
                                "group": "root",
                                "content": { "Fn::Join": [ "\n", [
                                    "node default {",
                                    "  class {'java' : package => 'jdk', version => '1.6.0_45-fcs'}",
                                    "  include jetty",
                                    "  include evolve",
                                    "  include emacs",
                                    "  include evolve::nfsclient",
                                    "  include oracle_jars",
                                    "  include evolve::ephemeral_logs",
                                    "  include evolve::evolve_user",
                                    "  include evolve::observer_user",
                                    "  include evolve::feeds_user",
                                    "  include evolve::evolve_zabbix_register",
                                    "  include jetty::tomcat_pooling_jars",
                                    "  include jetty::ephemeral_logs",
                                    "  include timezone::utc",
                                    "  include evolve::evolve_ulimits",
                                    "  include evolve::evolve_dynatrace",
                                    "  include evolve::jetty_workdir",
                                    "  include evolve::jetty_logging",
                                    "  include deploy",
                                    "}"
                                	] ] }
								}
							}
						},

                    "utils-config": {
                    	"files": {
                    	    "/var/els/puppet/manifests/nodes.pp": {
                    			"mode": "000644",
                    			"owner": "root",
                    			"group": "root",
                    			"content": {"Fn::Join": ["\n", [
		                    	    "node default {",
		                    	    "  class {'java' : package => 'jdk', version => '1.6.0_45-fcs'}",
		                                "  include jetty",
		                                "  include evolve",
		                                "  include emacs",
		                                "  include evolve::nfsserver",
		                                "  include evolve::utils_crontab",
		                                "  include evolve::ephemeral_logs",
		                                "  include evolve::evolve_user",
		                                "  include evolve::observer_user",
		                                "  include evolve::evolve_zabbix_register",
		                                "  include jetty::tomcat_pooling_jars",
		                                "  include jetty::ephemeral_logs",
		                                "  include evolve::jetty_workdir",
		                                "  include timezone::utc",
		                                "  include evolve::evolve_ulimits",
		                                "  include evolve::jetty_logging",
		                                "  include evolve::utils_content",
		                                "  include evolve::utils_crontab",
		                                "  include evolve::utils_scripts",
		                                "  include evolve::evolve_dynatrace",
		                                "  include solr",
		                                "  include evolve::solr_master_config",
                                        "  include deploy",
		                                "}"
		                    	] ] }
		                    }
						}
                	}	
            	}
			},
            "Properties":{
                "InstanceMonitoring": false,
                "ImageId":{
                    "Fn::FindInMap":[
                        "RegionMap",
                        {
                            "Ref":"AWS::Region"
                        },
                        "app"
                    ]
                },
                "InstanceType":{
                    "Fn::FindInMap":[
                        "RegionMap",
                        {
                            "Ref":"AWS::Region"
                        },
                        "type"
                    ]
                },
                "KeyName":{
                    "Ref":"KeyPair"
                },
                "SecurityGroups":[
                    {
                        "Ref":"WebServiceSG"
                    }
                ],
                "UserData":{
                    "Fn::Base64":{
                        "Fn::Join":[
                            "\n",
                            [
                                "#!/bin/bash",
                                "# Install cfn-bootstrap tools and dependancies",
                                "yum install -y pystache python-daemon python-requests",
                                "rpm -ihv 'http://com.ptgels.yum.s3.amazonaws.com/prod/RPMS/6/x86_64/a/aws-cfn-bootstrap-1.3-b123.noarch.rpm?Signature=DeQCtrVFJ7S8UyfCOI89gsbrcRE%3D&Expires=1687794783&AWSAccessKeyId=AKIAIORP42DF6SY7FVRA&x-amz-meta-s3cmd-attrs=uid%3A48/gname%3Aapache/uname%3Aapache/gid%3A48/mode%3A33188/mtime%3A1379338448/atime%3A1379361086/ctime%3A1379361085'",
                                { "Fn::Join" : [ " ", [
                                  "/opt/aws/bin/cfn-init",
                                  "-s",
                                  { "Ref" : "AWS::StackName" },
                                  "-r",
                                  "WebServiceAutoScaleLaunchConfiguration",
                                  "--region",
                                  { "Ref" : "AWS::Region" },
                                  "--access-key",
                                  { "Ref" : "WebServiceUserKey" },
                                  "--secret-key",
                                  { "Fn::GetAtt" : [ "WebServiceUserKey", "SecretAccessKey" ] },
                                  "-c",
                                  "default,appserver",
                                  "-v"
                                ]]},
                                "",
                                "/usr/bin/puppet apply /var/els/puppet/manifests/site.pp --modulepath /var/els/puppet/modules --debug",
                                ""
                            ]
                        ]
                    }
                }
            }
        },
        "EnvironmentConfigDomain":{
            "Type":"AWS::SDB::Domain"
        },
        "WebServiceUser":{
            "Type":"AWS::IAM::User",
            "Properties":{
                "Path":"/",
                "Groups":[
                    "route53-register",
                    "puppet_access"
                ],
                "Policies":[
                    {
                        "PolicyName":"ConfigSDBAccessPolicy",
                        "PolicyDocument":{
                            "Statement":[
                                {
                                    "Effect":"Allow",
                                    "Action":[
                                        "sdb:DomainMetadata",
                                        "sdb:GetAttributes",
                                        "sdb:Select"
                                    ],
                                    "Resource":[
                                        {
                                            "Fn::Join":[
                                                ":",
                                                [
                                                    "arn",
                                                    "aws",
                                                    "sdb",
                                                    {
                                                        "Ref":"AWS::Region"
                                                    },
                                                    "*",
                                                    {
                                                        "Fn::Join":[
                                                            "/",
                                                            [
                                                                "domain",
                                                                {
                                                                    "Ref":"EnvironmentConfigDomain"
                                                                }
                                                            ]
                                                        ]
                                                    }
                                                ]
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        "PolicyName": "StackMetadataAccess",
                        "PolicyDocument": {
                            "Statement": [
                                {
                                    "Effect": "Allow",
                                    "Action": [
                                        "cloudformation:DescribeStackResource"
                                    ],
                                    "Resource": [
                                        "*"
                                    ]
                                }
                            ]
                        }
                    }
                ]
            }
        },
        "WebServiceUserKey":{
            "Type":"AWS::IAM::AccessKey",
            "Properties":{
                "Serial":1,
                "UserName":{
                    "Ref":"WebServiceUser"
                }
            }
        },
        "UtilsServiceELBIngress8080": {
			"Type" : "AWS::EC2::SecurityGroupIngress",
			"Properties" : {
			    "GroupName": {"Ref": "UtilsServiceSG"},
				"IpProtocol" : "tcp",
				"FromPort" : "8080",
				"ToPort" : "8080",
				"SourceSecurityGroupOwnerId" : {"Fn::GetAtt": ["UtilsServiceELB", "SourceSecurityGroup.OwnerAlias"]},
				"SourceSecurityGroupName": { "Fn::GetAtt": ["UtilsServiceELB", "SourceSecurityGroup.GroupName"]}
			}
        },
        "UtilsServiceELB" : {
    		"Type" : "AWS::ElasticLoadBalancing::LoadBalancer",
    		"Properties" : {
				"AvailabilityZones" : { "Fn::GetAZs" : { "Ref" : "AWS::Region" } },
    			"HealthCheck" : {
    				"HealthyThreshold" : "3",
    				"Interval" : "5",
    				"Target" : "HTTP:8080/solr/select?q=%28%28author%3A%28*jarvis*%29^35%20OR%20name%3A%28*jarvis*%29^30%20OR%20productTypeName%3A%28*jarvis*%29^27%20OR%20resourceId%3A%28*jarvis*%29^5%20OR%20isbn10%3A%28*jarvis*%29^10%20%29%20AND%20%28coreProductFlag%3A*Y*^50%20%20OR%20coreProductFlag%3A*N*^2%29%20%29AND%20role%3Afaculty%20AND%20faculty-publish-flag%3AY%20AND%20faculty-search-flag%3AY&rows=25&start=0&facet=true&wt=json&facet.field=productType&facet.field=availableFormat&facet.zeros=false&sort=score%20desc%2CcontactOriginRelevancy%20desc%2Crelevancy%20desc%2Cedition%20desc&fl=*%2Cscore&fq=",
    				"Timeout" : "3",
    				"UnhealthyThreshold" : "2"
    			},
    			"Listeners" : [
    				{
    					"Protocol" : "HTTP",
    					"LoadBalancerPort" : "80",
    					"InstancePort" : "8080"
    				},
    				{
    					"Protocol": "HTTPS",
    					"LoadBalancerPort": "443",
    					"InstancePort": "8080",
         				"SSLCertificateId" : "arn:aws:iam::735504175433:server-certificate/Users/whitea002/tmp/evolve/STAR_EHSEVOLVE_COM"
    				}
    			]
    		}
    	},
        "UtilsServiceDNS" : {
    		"Type" : "AWS::Route53::RecordSetGroup",
    		"Properties" : {
    			"HostedZoneName" : { "Ref" : "DNSDomain" },
    			"Comment" : { "Fn::Join" : ["", [
    			            "Alias record for Elastic Loadbalancer ",
    			            { "Ref" : "DNSDomain" },
    			            "."
    			        ]
    			    ]
    			},
    			"RecordSets" : [    			    
    			    {
    			    	"Name" : {"Fn::FindInMap": ["DNSMap", {"Ref":"Environment"}, "solr"]},
	    				"Type" : "A",
	    				"AliasTarget" : {
	    					"HostedZoneId" : { "Fn::GetAtt" : [ "UtilsServiceELB", "CanonicalHostedZoneNameID" ] },
	    					"DNSName" : { "Fn::GetAtt" : [ "UtilsServiceELB", "CanonicalHostedZoneName" ] }
	    				}
    			    },
    			    {
    			    	"Name" : {"Fn::FindInMap": ["DNSMap", {"Ref":"Environment"}, "utils"]},
	    				"Type" : "A",
	    				"AliasTarget" : {
	    					"HostedZoneId" : { "Fn::GetAtt" : [ "UtilsServiceELB", "CanonicalHostedZoneNameID" ] },
	    					"DNSName" : { "Fn::GetAtt" : [ "UtilsServiceELB", "CanonicalHostedZoneName" ] }
	    				}
    			    }
    			]	
    		}
    	},
        "UtilsServiceAutoscaleGroup":{
            "Type":"AWS::AutoScaling::AutoScalingGroup",
            "Properties":{
                "AvailabilityZones":{
                    "Fn::GetAZs":{
                        "Ref":"AWS::Region"
                    }
                },
                "Cooldown":"300",
                "DesiredCapacity":"1",
                "HealthCheckGracePeriod":"300",
                "HealthCheckType":"EC2",
                "LaunchConfigurationName":{
                    "Ref":"UtilsServiceAutoScaleLaunchConfiguration"
                },
                "MaxSize":"1",
                "MinSize":"1",
                "LoadBalancerNames": [{ "Ref": "UtilsServiceELB" }],
                "Tags":[
                    {
                    "Key":"Name",
                   		"Value":{"Fn::Join":["-", ["utilsservice", {"Ref":"AWS::StackName"}]]
                        },
                        "PropagateAtLaunch":"true"
                    },
                    {
                    "Key":"ConfigDomain",
                        "Value":{"Ref":"EnvironmentConfigDomain"
                        },
                        "PropagateAtLaunch":"true"
                    },
                    { "Key":"HostConfiguration",
                    	"Value": {"Fn::Join":[":", [
                            {"Fn::Join": [ "", [
                                "HOST=", {"Fn::FindInMap": ["DNSMap", {"Ref":"Environment"}, "solr"]}
                            ]]},
                            {"Fn::Join": [ "", [
                                "HOST=", {"Fn::FindInMap": ["DNSMap", {"Ref":"Environment"}, "utils"]}
                            ]]}
                        ]]},
                    	"PropagateAtLaunch":"true"
                    }
                ]
            }
        },
        "UtilsServiceAutoScaleLaunchConfiguration":{
            "Type":"AWS::AutoScaling::LaunchConfiguration",
            "Properties":{
                "InstanceMonitoring": false,
                "ImageId":{
                    "Fn::FindInMap":[
                        "RegionMap",
                        {
                            "Ref":"AWS::Region"
                        },
                        "app"
                    ]
                },
                "InstanceType":{
                    "Fn::FindInMap":[
                        "RegionMap",
                        {
                            "Ref":"AWS::Region"
                        },
                        "type"
                    ]
                },
                "KeyName":{
                    "Ref":"KeyPair"
                },
                "SecurityGroups":[
                    {
                        "Ref":"UtilsServiceSG"
                    }
                ],
                "UserData":{
                    "Fn::Base64":{
                        "Fn::Join":[
                            "\n",
                            [
                                "#!/bin/bash",
                                "# Install cfn-bootstrap tools and dependancies",
                                "yum install -y pystache python-daemon python-requests",
                                "rpm -ihv 'http://com.ptgels.yum.s3.amazonaws.com/prod/RPMS/6/x86_64/a/aws-cfn-bootstrap-1.3-b123.noarch.rpm?Signature=DeQCtrVFJ7S8UyfCOI89gsbrcRE%3D&Expires=1687794783&AWSAccessKeyId=AKIAIORP42DF6SY7FVRA&x-amz-meta-s3cmd-attrs=uid%3A48/gname%3Aapache/uname%3Aapache/gid%3A48/mode%3A33188/mtime%3A1379338448/atime%3A1379361086/ctime%3A1379361085'",
                                { "Fn::Join" : [ " ", [
                                  "/opt/aws/bin/cfn-init",
                                  "-s",
                                  { "Ref" : "AWS::StackName" },
                                  "-r",
                                  "WebServiceAutoScaleLaunchConfiguration",
                                  "--region",
                                  { "Ref" : "AWS::Region" },
                                  "--access-key",
                                  { "Ref" : "WebServiceUserKey" },
                                  "--secret-key",
                                  { "Fn::GetAtt" : [ "WebServiceUserKey", "SecretAccessKey" ] },
                                  "-c",
                                  "default,utils",
                                  "-v"
                                ]]},
                                "",
                                "/usr/bin/puppet apply /var/els/puppet/manifests/site.pp --modulepath /var/els/puppet/modules --debug",
                                ""
                            ]
                        ]
                     }
                }
            }
        },
        "EnvironmentConfigDomain":{
            "Type":"AWS::SDB::Domain"
        },
        "UtilsServiceSG":{
            "Type":"AWS::EC2::SecurityGroup",
            "Properties":{
                "GroupDescription":"Security Group to contain the possible utility server",
                "SecurityGroupIngress":[
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"22",
                        "ToPort":"22"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"0.0.0.0/0",
                        "FromPort":"8080",
                        "ToPort":"8080"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"96.41.98.176/32",
                        "FromPort":"22",
                        "ToPort":"22"
                    },
                    {
                        "IpProtocol":"tcp",
                        "CidrIp":"198.185.18.0/24",
                        "FromPort":"1521",
                        "ToPort":"1521"
                    },
                    {
                        "IpProtocol":"tcp",
                        "SourceSecurityGroupId": "sg-7c37bf14",
                        "SourceSecurityGroupOwnerId": "288860632658",
                        "FromPort":"10050",
                        "ToPort":"10052"
                    }
                ]
            }
        }
    },
        
    "Outputs":{
        "ConfigXML":{
            "Value":{
                "Fn::Join":[
                    "\n",
                    [
                        "<Domain>",
                        "  <Item id=\"configuration\">",
                        "  </Item>",
                        "</Domain>"
                    ]
                ]
            }
        }
    }
}
