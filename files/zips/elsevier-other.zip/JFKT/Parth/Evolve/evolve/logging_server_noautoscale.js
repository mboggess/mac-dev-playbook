{
  "AWSTemplateFormatVersion": "2010-09-09",
  "Description": "Template to create a sandbox environment",
  "Parameters": {
    "DNSDomain": {
      "Type": "String",
      "Description": "The DNS domain to create records in. Must be the complete domain name, ending in .",
      "AllowedPattern": "[a-z0-9_\\-\\.]*\\.$",
      "ConstraintDescription": "most only contain lower case letters, numbers, hyphens, periods, and underscores. It must end with a period"
    },
    "KeyPair": {
      "Type": "String",
      "Description": "Keypair name to use on this system. The keypair must already exist in EC2.",
      "Default": ""
    }
  },
  "Mappings": {
    "RegionMap": {
      "us-east-1": {
        "app": "ami-5aab7033",
        "type": "m1.small"
      }
    }
  },
  "Resources": {
    "LogServiceSG": {
      "Type": "AWS::EC2::SecurityGroup",
      "Properties": {
        "GroupDescription": "Security Group to contain the Log Server",
        "SecurityGroupIngress": [
          {
            "IpProtocol": "tcp",
            "CidrIp": "198.185.18.72/32",
            "FromPort": "22",
            "ToPort": "22"
          },
          {
            "IpProtocol": "tcp",
            "CidrIp": "198.185.18.207/32",
            "FromPort": "80",
            "ToPort": "80"
          },
          {
            "IpProtocol": "tcp",
            "CidrIp": "0.0.0.0/32",
            "FromPort": "514",
            "ToPort": "514"
          }
        ]
      }
    },
    "LogServiceConfiguration": {
      "Type": "AWS::EC2::Instance",
      "Properties": {
        "ImageId": {
          "Fn::FindInMap": [
            "RegionMap",
            {
              "Ref": "AWS::Region"
            },
            "app"
          ]
        },
        "InstanceType": {
          "Fn::FindInMap": [
            "RegionMap",
            {
              "Ref": "AWS::Region"
            },
            "type"
          ]
        },
        "KeyName": {
          "Ref": "KeyPair"
        },
        "SecurityGroups": [
          {
            "Ref": "LogServiceSG"
          }
        ],
        "UserData": {
          "Fn::Base64": {
            "Fn::Join": [
              "\n",
              [
                "#!/bin/bash",
                {
                  "Fn::Join": [
                    "=",
                    [
                      "ACCESS_KEY",
                      {
                        "Ref": "LogServiceUserKey"
                      }
                    ]
                  ]
                },
                {
                  "Fn::Join": [
                    "=",
                    [
                      "SECRET_KEY",
                      {
                        "Fn::GetAtt": [
                          "LogServiceUserKey",
                          "SecretAccessKey"
                        ]
                      }
                    ]
                  ]
                },
                "mkdir -p /var/els/tmp",
                "cat >/var/els/tmp/.s3cfg<<EOF",
                "[default]",
                "access_key = $ACCESS_KEY",
                "secret_key = $SECRET_KEY",
                "use_https = True",
                "EOF",
                "/usr/bin/s3cmd -c /var/els/tmp/.s3cfg sync s3://evolve.aws.puppet/dev/puppet /var/els/",
                "cat >/var/els/creds.properties<<EOF",
                "accessKey = $ACCESS_KEY",
                "secretKey = $SECRET_KEY",
                {
                  "Fn::Join": [
                    "",
                    [
                      "dns.domain = ",
                      {
                        "Ref": "DNSDomain"
                      }
                    ]
                  ]
                },
                {
                  "Fn::Join": [
                    "",
                    [
                      "envConfigDomain = ",
                      {
                        "Ref": "EnvironmentConfigDomain"
                      }
                    ]
                  ]
                },
                "EOF",
                "cat >/var/els/puppet/manifests/nodes.pp<<EOF",
                "node default {",
                "  class {'java' : version => '1.6.0_37-fcs'}",
                "  include tomcat",
                "  include apache",
                "  include timezone::utc",
                "}",
                "EOF",
                "",
                "rm -rf /var/els/tmp",
                "/usr/bin/puppet apply /var/els/puppet/manifests/site.pp --modulepath /var/els/puppet/modules --debug",
                "",
                "EOF"
              ]
            ]
          }
        }
      }
    },
    "LogServiceUser": {
      "Type": "AWS::IAM::User",
      "Properties": {
        "Path": "/",
        "Groups": [
          "route53-register",
          "puppet_access"
        ],
        "Policies": [
          {
            "PolicyName": "ConfigSDBAccessPolicy",
            "PolicyDocument": {
              "Statement": [
                {
                  "Effect": "Allow",
                  "Action": [
                    "sdb:DomainMetadata",
                    "sdb:GetAttributes",
                    "sdb:Select"
                  ],
                  "Resource": [
                    {
                      "Fn::Join": [
                        ":",
                        [
                          "arn",
                          "aws",
                          "sdb",
                          {
                            "Ref": "AWS::Region"
                          },
                          "*",
                          {
                            "Fn::Join": [
                              "/",
                              [
                                "domain",
                                {
                                  "Ref": "EnvironmentConfigDomain"
                                }
                              ]
                            ]
                          }
                        ]
                      ]
                    }
                  ]
                }
              ]
            }
          }
        ]
      }
    },
    "LogServiceUserKey": {
      "Type": "AWS::IAM::AccessKey",
      "Properties": {
        "Serial": 1,
        "UserName": {
          "Ref": "LogServiceUser"
        }
      }
    },
    "EnvironmentConfigDomain": {
      "Type": "AWS::SDB::Domain"
    }
  },
  "Outputs": {
    "ConfigXML": {
      "Value": {
        "Fn::Join": [
          "\n",
          [
            "<Domain>",
            "  <Item id=\"configuration\">",
            "  </Item>",
            "</Domain>"
          ]
        ]
      }
    }
  }
}
