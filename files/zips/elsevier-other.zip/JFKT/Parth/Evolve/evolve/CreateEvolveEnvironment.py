#!/usr/bin/python

import boto
import argparse
import time
import sys
from boto.exception import SDBResponseError

from StringIO import StringIO

sdb_conn = boto.connect_sdb()
sns_conn = boto.connect_sns()
sqs_conn = boto.connect_sqs()
cf_conn = boto.connect_cloudformation()

# Parameters to pass to cloudformation
 
cf_params = {
     'DNSDomain' : 'ehsevolve.com.',
     'KeyPair' : 'EVroot_nonprod',
}

def load_cf_template(json_file):
    if hasattr(json_file,"read"):
        return str(json_file.read())
    else:
        return str(open(json_file).read())

def parse_arguments():
    parser = argparse.ArgumentParser()
    
    parser.add_argument("stack_name", help = "The name of the stack to create. A stack by this name must not already exist.")
#    parser.add_argument("--environment", help = "The environment name of the stack. Only used to find/create the SNS topic.", default = None, action = "store")
    parser.add_argument("--template-file", required = True, dest="template", help = "The CloudFormation template file to load", action = "store", type=argparse.FileType('r'))
    # TODO: Make this somehow take pairs of Logical Table Names and xml files. Load arbritrary numbers of SDB domains
#    parser.add_argument("--xml-file", help = "XML file to load into the SDB config domain", dest = "xml_file", action = "store", type=argparse.FileType('r'))
    parser.add_argument("--debug", help = "Turn on boto debugging", dest = "debug", default = False, action = "store_true")
    parser.add_argument("--runLevel", help = "Contents of /l-n/app/etc/runLevel", dest="runLevel", default = None, action = "store")
    return parser.parse_args()

# TODO: Pull out the table logical names into some kind of configuration
def load_sdb_domain(domain_name, xml_file):
    try:
        domain = sdb_conn.get_domain(domain_name)
    except SDBResponseError,e:
        print "Error retrieving SDB domain '%s':" % domain_name
        print e
        raise e
    try:
        # Since the passed 'doc' is sent straight on to xml.sax.parse, we can pass a filename or file-like object here.
        domain.from_xml(xml_file)
    except Exception,e:
        print "Error loading SDB domain '%s' from file." % domain_name
        print e
        raise e
        
def call_cloudformation(stack_name, template_file):    
    body = load_cf_template(template_file)
    params = [(k,v) for k,v in cf_params.iteritems()] # Converts a hash to a list of tuples
    print params
    stack = cf_conn.create_stack(stack_name,
         template_body = body,
         parameters = params, 
         capabilities = ['CAPABILITY_IAM'],
         # This sent > 50 spam messages. One for the start and end of each resource
         #notification_arns = ['arn:aws:sns:us-east-1:030665241629:stack-complete-notification'],
     )
    
    return stack
    
# TODO: See if we need to file a bug on this...
def get_stack_by_name(stack_name):
    # describe_stacks with a name or ID still returns the entire list. Filter myself.
    return filter(lambda x: x.stack_name == stack_name, cf_conn.describe_stacks())[0]

def create_update_write_topic(topic_name):
    print "Topic %s does not exist, creating" % topic_name
    sns_conn.create_topic(topic_name)

def get_topic_by_name(name):
    all_topics = sns_conn.get_all_topics()['ListTopicsResponse']['ListTopicsResult']['Topics']
    
    try:
        return filter(lambda x: x['TopicArn'].endswith(":%s" % name), all_topics)[0]
    except IndexError:
        return []

def get_update_write_topic_arn(environment):
    topic_name = "DynamoDBUpdateTopic-%s" % environment
    my_topic = get_topic_by_name(topic_name)
    if my_topic == []:
        print "Creating DynamoDB Update SNS Topic"
        create_update_write_topic(topic_name)
        print "Waiting for SNS Topic to become available",
        while my_topic == []:
            time.sleep(2)
            print ".",
            sys.stdout.flush()
            my_topic = get_topic_by_name(topic_name)
        print "done."
            
    return my_topic['TopicArn']

if __name__ == "__main__":
    options = parse_arguments()
    if options.runLevel is None:
        print "Error: runLevel missing!"
        sys.exit(1)
        
    if options.debug:
        boto.set_stream_logger('boto')
            
    stack_name = options.stack_name
    template_file = options.template
    
    # Fail fast
    try:
        stack = get_stack_by_name(stack_name)
        # If we get to this point, the stack already exists
        print "Error: Stack '%s' already exists" % stack_name
        sys.exit(1)
    except IndexError:
        pass

    stack_id = None
    cf_params["runLevel"] = options.runLevel
    
    print "Calling CloudFormation to create the stack."
    try:
        stack_id = call_cloudformation(stack_name, template_file)
    except Exception, e:
        print "There was an error creating the stack:"
        print e
        sys.exit(1)

    try:
        stack = cf_conn.describe_stacks(stack_id)[0]
    except Exception,e:
        print "Exception creating stack:"
        print e
        sys.exit(1)
    
    print "Waiting on CloudFormation to finish building the stack (this will take several minutes):",
    sys.stdout.flush()
    # describe_stacks with a stack name doesn't seem to work
    stack = get_stack_by_name(stack_name)
    while True:
        # Stack.update() returns an error
        # TODO: See if we need to file a bug on this
        stack = get_stack_by_name(stack_name)
        if stack.stack_status == 'CREATE_IN_PROGRESS':
            print ".",
            sys.stdout.flush()
            time.sleep(30)
        elif stack.stack_status == 'CREATE_FAILED':
            print
            print "Error in stack creation."
            sys.exit(1)
        elif stack.stack_status  == 'CREATE_COMPLETE':
            print "Done!"
            break
        elif stack.stack_status == 'ROLLBACK_COMPLETE':
            print "Rollback complete. Can not continue."
            sys.exit(1)
        elif stack.stack_status == 'DELETE_COMPLETE':
            print "Stack has been deleted, can not continue."
            sys.exit(1)
        else:
            print "Stack status = %s" % stack.stack_status
            time.sleep(30)
        
    stack = get_stack_by_name(stack_name)
    # For now we're pulling the XML fully formed from CloudFormation.
    outputs = {}
    for output in stack.outputs:
        outputs[output.key] = output.value
        
    resources = {}
    for resource in stack.list_resources():
        resources[resource.logical_resource_id] = resource.physical_resource_id
       
#    # Commented SDB domain load for Evolve (not necessary at this time) 
#    if ('ConfigXML' in outputs) and ('EnvironmentConfigDomain' in resources):
#        # We're creating a StringIO so that the load_from_xml method sees the string as a file-like object
#        xml = StringIO(outputs['ConfigXML'])
#        load_sdb_domain(resources['EnvironmentConfigDomain'], xml)
        
#    # Commented out SNS topic and SQS creation for Evolve (not necessary at this time)
#    topic_name = "%s-%s" % (options.stack_name, options.runLevel)
#    print "Subscribing DB Writer Queue to Topic"
#    topic_arn = get_update_write_topic_arn(topic_name)
#    
#    queue_name = outputs['DynamoDBWriteQueue']
#    queue = sqs_conn.get_queue(queue_name)
#    if queue is None:
#        print "Error: Can't find queue with name %s" % queue_name
#        sys.exit(1)
#    try:
#        boto.set_stream_logger('boto')
#        sns_conn.subscribe_sqs_queue(topic_arn, queue)
#    except Exception,e:
#        print e
        
    print "All done!"
