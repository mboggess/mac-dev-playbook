This repository holds all the Cloud Formation Templates to create new Evolve servers for VPC and EC2-Classic. You should always verify the parameters while firing up the stack.

Stable Puppet Build # - 00508