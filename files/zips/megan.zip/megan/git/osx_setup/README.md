# osx-setup
1. Install ansible
2. Apply playbook to local host
Repo for notes, scripts, files facilitating easy setup of an OSX machine.
